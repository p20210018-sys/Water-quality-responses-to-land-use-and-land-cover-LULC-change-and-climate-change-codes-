# LULC and Environmental Change Analysis – Supporting Code and Data

This repository contains the original Jupyter notebooks and the data values embedded in those notebooks. It is intended to support transparency and reproducibility of the analyses reported in the associated research manuscript.

## Repository contents

### Notebooks
- `notebooks/Mining_Updated_Original.ipynb` – latest Mining notebook supplied by the author. It maps lead-associated ore extraction values for Algeria, Egypt, Morocco, Tunisia, and Libya.
- `notebooks/Agriculture_Updated_Original.ipynb` – latest Agriculture notebook supplied by the author, containing annual agricultural-land values and related change/growth visualisations (1961–2023).
- `notebooks/Forest_Cover_Updated_Original.ipynb` – latest forest-cover notebook supplied by the author. It includes original and Hamed–Rao modified Mann–Kendall tests, Sen's slope visualisation, annual-change plots, and a heat-strip plot.

The latest Mining notebook, latest Agriculture notebook, and latest Forest Cover notebook are retained as uploaded. Their code and analysis steps have not been silently rewritten.

### Data
- `data/mining_embedded_data.csv` – country and lead-associated ore extraction values embedded in the Mining notebook.
- `data/agriculture_embedded_data.csv` – annual values embedded in the Agriculture notebook.
- `data/forest_cover_embedded_data.csv` – year and forest-cover values extracted from the earlier Forest Cover notebook supplied in this conversation. The latest `Forest_Cover_Updated_Original.ipynb` does not itself define the `years` and `forest_cover` arrays.

These CSV files are extracted from the notebooks; they are not independent external data downloads.

### Other files
- `requirements.txt` – Python package requirements for the analyses.
- `outputs/` – reserved for generated figures and tables.

## How to run

1. Download or clone this repository.
2. Open the required `.ipynb` notebook in Google Colab or Jupyter Notebook.
3. Install the packages listed in `requirements.txt` if they are not already available.
4. Run the notebook cells in order.
5. Some notebooks use external geographic boundary data or Google Colab-specific file download commands. Internet access may be required for those cells, and Colab-specific commands may need adjustment when using local Jupyter.

## Important data and metadata notes

- The latest Agriculture notebook uses the variable name `Agri_Land_Increase_%` and contains annual values for 1961–2023. The notebook does not clearly document the country, original data source, indicator definition, and units. Confirm these details and add the source citation before describing the values as a particular country's official agricultural-land series.
- The latest Mining notebook lists Algeria, Egypt, Morocco, Tunisia, and Libya and labels the values as lead-associated ore extraction in tonnes. It also uses the output filename `ferrous_ore_choropleth` while the map title describes lead-associated ore extraction. Confirm the intended commodity terminology, original data source, and reference year, and resolve this filename/title inconsistency before publication.
- The latest Forest Cover notebook labels its visualisations as Algeria and specifies forest cover in square kilometres. It refers to `years` and `forest_cover` variables but does not define them in the uploaded notebook. The accompanying CSV was extracted from an earlier supplied Forest Cover notebook and should be checked against the intended source data before use. Add the original data source, indicator definition, and access date. To make the latest notebook executable, add a cell that reads the CSV and defines `years` and `forest_cover` before the analysis cells.
- The CSV files reproduce values embedded in the notebooks. They do not validate the accuracy, provenance, or interpretation of those values.

## Reproducibility and citation

Please cite the associated research article when reusing the code or data. For a stable, citable archive, create a GitHub release and archive that release with Zenodo to obtain a DOI. Update this README with the DOI and the final repository URL after publication.

## License

No license is assigned in this starter repository. Add a license only after confirming that you have the rights to license the code and data. A license for code does not automatically grant rights to third-party datasets.
